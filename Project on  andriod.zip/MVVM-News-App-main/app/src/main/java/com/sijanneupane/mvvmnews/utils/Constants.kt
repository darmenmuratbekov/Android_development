package com.sijanneupane.mvvmnews.utils

class Constants {
    companion object{
        const val API_KEY= "a7ebed0b55b041e7a20fc6ef542c5322"
        const val BASE_URL= "https://newsapi.org"
        const val SEARCH_DELAY= 500L
        const val QUERY_PAGE_SIZE= 20
    }
}