package com.sijanneupane.mvvmnews

import android.app.Application

class NewsApplication : Application()