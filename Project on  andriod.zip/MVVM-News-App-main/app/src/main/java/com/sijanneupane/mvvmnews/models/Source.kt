package com.sijanneupane.mvvmnews.models

data class Source(
    val id: Any,
    val name: String
)