# MVVM-News-App
# This is A News app in MVVM Architecture in Kotlin using Retrofit, Room, Coroutines, and Navigation Components

# It retrieves Data Using Retrofit From A News Api #(https://newsapi.org/).

# It uses the latest Jetpack Compose libraries And methods For Build,Mentioned Above.

# Some Of Insights of App is:

# This is Home Screen of the App .From the Bottom navigation Bar u Can Search ,Go to your Saved News Etc

# ![Android Emulator - Pixel_5_API_29_5554 03-Oct-21 10_14_25 PM](https://user-images.githubusercontent.com/89447707/135767419-69148875-bb70-4155-aa4a-d634c1699663.jpg)

 # This is Detailed News Which Appears When Person Clicks on A Certain News.
 
# ![Android Emulator - Pixel_5_API_29_5554 03-Oct-21 10_15_38 PM](https://user-images.githubusercontent.com/89447707/135767553-c2360790-4f3c-45e4-87e6-601a9fd80fe0.jpg)
 
 # This the Search Fragment .Whenever we Type Something News Relevant To it Appears.
 # ![Android Emulator - Pixel_5_API_29_5554 03-Oct-21 10_14_41 PM](https://user-images.githubusercontent.com/89447707/135767673-2932f578-c3e8-4d73-9994-d6aafe040184.jpg)

 
 # These Are News Saved By Us When We click on Heart Icon In The Detailed News Section.
 
 # ![Android Emulator - Pixel_5_API_29_5554 03-Oct-21 10_15_44 PM](https://user-images.githubusercontent.com/89447707/135767494-0ddc9a00-acfb-4f2f-b468-4efc99cf1ac8.jpg)
 
# Thanks For Giving Precious Time to go through my repository.
